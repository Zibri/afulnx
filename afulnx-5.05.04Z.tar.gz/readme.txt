AMI Bios flasher modified to work on Ubuntu 18.X.
Enginnering mode flag: /EGM:1
GAN flag also active.
Have fun and drop me a line if you like it: zibri AT zibri DOT org.
